USE AdventureWorks2014;
GO

SELECT 
	PC.Name AS Category,
	PSC.Name AS SubCategory,
	PM.Name AS Model,
	P.Name AS Product,
	P.ListPrice AS Price
FROM Production.Product AS P
	FULL JOIN Production.ProductModel AS PM
		ON PM.ProductModelID = P.ProductModelID
	FULL JOIN Production.ProductSubcategory AS PSC
		ON PSC.ProductCategoryID = P.ProductSubcategoryID
	JOIN Production.ProductCategory AS PC
		ON PC.ProductCategoryID = PSC.ProductCategoryID
ORDER BY PC.Name, PSC.Name;
GO