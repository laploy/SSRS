CREATE TABLE SalesPerYear 
 (Id INT PRIMARY KEY IDENTITY(1,1),
SalesYear INT,
Amount Float)
 
 
INSERT INTO SalesPerYear 
VALUES    ('2016','77'),('2017','66'),('2018','50') ,('2019','60'),('2020','73')