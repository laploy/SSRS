SELECT        
	P.FirstName, 
	P.LastName, 
	SOH.OrderDate, 
	DATEPART(yy, SOH.OrderDate) AS [Year],
	DATEPART(mm, SOH.OrderDate) AS [Month],
	SOH.SalesOrderNumber, 
	SOH.SalesPersonID, ST.Name, 
	ST.CountryRegionCode, 
	ST.[Group], PP.Name AS ProductName, 
	PP.Color, 
	PP.Size, 
	SD.OrderQty,
	SD.LineTotal,
	PPS.Name AS SubCat,
	PPC.Name AS CatName,
	SUM(SD.OrderQty) AS Qty,
	SUM(SD.LineTotal) As LineTotal,
	CASE 
		WHEN PP.Size = 'S' THEN 1 
		WHEN PP.Size = 'M' THEN 2
		WHEN PP.Size = 'L' THEN 3
		WHEN PP.Size = 'XL' THEN 4
	END AS SizeSortOrder
FROM            
	Person.Person AS P INNER JOIN
    Sales.SalesPerson AS SP ON P.BusinessEntityID = SP.BusinessEntityID INNER JOIN
    Sales.SalesOrderHeader AS SOH ON SP.BusinessEntityID = SOH.SalesPersonID INNER JOIN
    Sales.SalesTerritory AS ST ON SP.TerritoryID = ST.TerritoryID INNER JOIN
    Sales.SalesOrderDetail AS SD ON SOH.SalesOrderID = SD.SalesOrderID INNER JOIN
    Production.Product AS PP ON SD.ProductID = PP.ProductID INNER JOIN
    Production.ProductSubcategory AS PPS ON PP.ProductSubcategoryID = PPS.ProductSubcategoryID AND PP.ProductSubcategoryID = PPS.ProductSubcategoryID AND PP.ProductSubcategoryID = PPS.ProductSubcategoryID AND 
    PP.ProductSubcategoryID = PPS.ProductSubcategoryID AND PP.ProductSubcategoryID = PPS.ProductSubcategoryID INNER JOIN
    Production.ProductCategory AS PPC ON PPS.ProductCategoryID = PPC.ProductCategoryID AND PPS.ProductCategoryID = PPC.ProductCategoryID AND PPS.ProductCategoryID = PPC.ProductCategoryID AND 
    PPS.ProductCategoryID = PPC.ProductCategoryID AND PPS.ProductCategoryID = PPC.ProductCategoryID
GROUP BY 
	P.FirstName, 
	P.LastName, 
	SOH.OrderDate, 
	SOH.SalesOrderNumber, 
	SOH.SalesPersonID, ST.Name, 
	ST.CountryRegionCode, 
	ST.[Group], PP.Name, 
	PP.Color, 
	PP.Size, 
	SD.OrderQty,
	SD.LineTotal,
	PPS.Name,
	PPC.Name
HAVING (DATEPART(yy,SOH.OrderDate) in ('2011' , '2012')
AND ST.[Group] = 'North America'
AND LEFT(PPS.Name,1) IN ('C', 'T', 'H')
)