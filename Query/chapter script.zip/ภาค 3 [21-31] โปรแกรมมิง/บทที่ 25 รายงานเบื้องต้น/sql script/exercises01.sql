USE AdventureWorks;
GO
SELECT TOP 20
	p.ProductID, 
	p.Name, 
	v.VendorID,
	v.MinOrderQty, 
	v.MaxOrderQty
FROM Production.Product p INNER JOIN 
	Purchasing.ProductVendor v ON 
		p.ProductID = v.ProductID
GO