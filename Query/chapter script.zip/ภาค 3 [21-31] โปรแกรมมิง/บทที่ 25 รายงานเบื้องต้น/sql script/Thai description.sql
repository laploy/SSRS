USE AdventureWorks2008;
GO
SELECT PM.ProductModelID, PM.Name AS [Product Model], Description, PL.CultureID, CL.Name AS Language
FROM Production.ProductModel AS PM 
    JOIN Production.ProductModelProductDescriptionCulture AS PL 
        ON PM.ProductModelID = PL.ProductModelID
    JOIN Production.Culture AS CL ON CL.CultureID = PL.CultureID
    JOIN Production.ProductDescription AS PD 
        ON PD.ProductDescriptionID = PL.ProductDescriptionID
WHERE CL.Name = 'Thai'
ORDER BY PM.ProductModelID ;
GO

