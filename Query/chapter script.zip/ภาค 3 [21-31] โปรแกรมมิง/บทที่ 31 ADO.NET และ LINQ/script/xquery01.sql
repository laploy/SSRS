DECLARE @x xml
SET @x='<?xml version="1.0" ?><p>Hello, World!</p>'
SELECT @x.value('(/p)[1]','varchar(max)');
GO