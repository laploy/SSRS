USE AdventureWorks2008;
GO
SELECT TOP 10 
	ProductID,
	Name,
	Color
FROM Production.Product
WHERE (Color IN('Black', 'White', 'Silver'));
GO