USE AdventureWorks;
GO
SELECT
	DepartmentID,
	Name,
	GroupName
FROM HumanResources.Department
ORDER BY DepartmentID;
GO