﻿using System.Text;

namespace Laploy.SQLBook.CustomAssembly
{
    public class LoyCA
    {
        public string WordChange(string s)
        {
            StringBuilder strBuilder = new StringBuilder(s);
            if (s.Contains("ML"))
            {
                strBuilder.Replace("ML", "Medium Length");
                return strBuilder.ToString();
            }
            else if (s.Contains("HL"))
            {
                strBuilder.Replace("HL", "Happy Land");
                return strBuilder.ToString();
            }
            else return s;
        }
    }
}