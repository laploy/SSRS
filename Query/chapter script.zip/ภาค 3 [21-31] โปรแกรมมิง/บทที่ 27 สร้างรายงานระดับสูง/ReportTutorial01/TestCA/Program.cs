﻿using System;
using Laploy.SQLBook.CustomAssembly;

namespace TestCA
{
    class Program
    {
        static void Main(string[] args)
        {
            LoyCA myCA = new LoyCA();
            string s = "HL this is test string";
            s = myCA.WordChange(s);
            Console.WriteLine(s);
        }
    }
}