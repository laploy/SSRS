SELECT
	FullName AS 'Name', 
	[2002] AS 'SalesBeforeLast', 
	[2003] AS 'SalesLastYear', 
	[2004] AS 'SalesYTD'
FROM Sales.vSalesPersonSalesByFiscalYears
