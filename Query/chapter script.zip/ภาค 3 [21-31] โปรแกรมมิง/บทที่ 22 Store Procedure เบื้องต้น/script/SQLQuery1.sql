USE AdventureWorks2008;
GO
SELECT 
	h.SalesOrderID,
	d.ProductID,
	d.UnitPrice,
	d.UnitPriceDiscount,
	d.OrderQty
FROM Sales.SalesOrderHeader h 
	JOIN Sales.SalesOrderDetail d
	ON h.SalesOrderID = d.SalesOrderID
WHERE h.SalesOrderID = 43659;
GO