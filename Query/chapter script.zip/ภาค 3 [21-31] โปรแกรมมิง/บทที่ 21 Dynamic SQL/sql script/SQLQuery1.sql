USE AdventureWorks2008;
DECLARE @min int = 990;
DECLARE @sql_stmt nvarchar(128) =
	N'SELECT ProductID, Name, ProductNumber ' +
	N'FROM Production.Product ' +
	N'WHERE ProductID >= ' + CAST(@min AS nvarchar(10));
EXECUTE (@sql_stmt);
GO