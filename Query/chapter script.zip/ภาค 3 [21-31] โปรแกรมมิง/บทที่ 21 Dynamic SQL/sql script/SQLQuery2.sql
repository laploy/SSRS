USE AdventureWorks2008;
SELECT top 20 
	ProductID, 
	Name, 
	ProductNumber
FROM Production.Product;
GO
SELECT top 20 
	ProductID, 
	Name, 
	ProductNumber
FROM Production.Product
ORDER BY Name
GO