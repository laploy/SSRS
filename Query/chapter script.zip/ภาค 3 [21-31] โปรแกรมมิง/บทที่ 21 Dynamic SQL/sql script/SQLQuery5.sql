USE AdventureWorks2008;
DECLARE @firstName	AS NVARCHAR(50) = 'Gail';
DECLARE @lastName	AS NVARCHAR(50) = 'Erickson';
DECLARE @mainQuery	AS NVARCHAR(128);
DECLARE @whereQuery AS NVARCHAR(128);

SET @mainQuery = 
	'SELECT BusinessEntityID, FirstName, ' + 
	'LastName, Title ' +
	'FROM Person.Person '
	
IF @firstName IS NULL AND @lastName IS NULL
	SET @whereQuery = 'WHERE BusinessEntityID < 10';
	
IF @firstName IS NULL AND @lastName IS NOT NULL
	SET @whereQuery = 'WHERE LastName = ''' + 
	@lastName  + ''''
	
IF @firstName IS NOT NULL AND @lastName IS NULL
	SET @whereQuery = 'WHERE firstName = ''' + 
	@firstName  + ''''
	
IF @firstName IS NOT NULL AND @lastName IS NOT NULL
	SET @whereQuery = 'WHERE firstName = ''' + 
	@firstName  + ''' AND LastName = ''' +
	@lastName  + ''''
	
EXEC(@mainQuery + @whereQuery);
GO