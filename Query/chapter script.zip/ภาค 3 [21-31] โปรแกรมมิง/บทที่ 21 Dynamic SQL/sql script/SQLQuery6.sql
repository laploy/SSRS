USE AdventureWorks2008;
DECLARE @param01	AS NVARCHAR (32);
DECLARE @input01	AS NVARCHAR(32);
DECLARE @mainQuery	AS NVARCHAR(128);
DECLARE @whereQuery AS NVARCHAR(128);

SET @mainQuery = 
	'SELECT BusinessEntityID, FirstName, ' + 
	'LastName, Title ' +
	'FROM Person.Person ' + 
	'WHERE firstName LIKE @firstName';
SET @param01 = '@firstName NVARCHAR(32)';

SET @input01 = 'Hazem';
EXECUTE sp_executesql 
	@mainQuery, @param01,
	@firstName = @input01;
	
SET @input01 = 'Ed';
EXECUTE sp_executesql 
	@mainQuery, @param01,
	@firstName = @input01;	
GO