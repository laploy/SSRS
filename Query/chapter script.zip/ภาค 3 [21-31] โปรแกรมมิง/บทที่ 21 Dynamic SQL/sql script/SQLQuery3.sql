USE AdventureWorks2008;
DECLARE @sortOrder TINYINT = 2;
SELECT top 20 
	ProductID, 
	Name, 
	ProductNumber
FROM Production.Product
ORDER BY 
	CASE 
		WHEN @sortOrder = 1 THEN Name
		WHEN @sortOrder = 2 THEN ProductNumber
	END
GO