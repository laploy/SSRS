USE AdventureWorks2008;
DECLARE @gender AS TINYINT = 2;
SELECT top 10
	BusinessEntityID, 
	FirstName, 
	LastName, 
	Title
FROM Person.Person
WHERE Title IS NOT NULL
GO