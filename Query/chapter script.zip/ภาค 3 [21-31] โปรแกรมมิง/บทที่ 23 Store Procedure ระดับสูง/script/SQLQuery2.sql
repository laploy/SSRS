USE AdventureWorks
GO
CREATE PROC spInsertValidatedStoreContact
	@CustomerID int,
	@ContactID int,
	@ContactTypeID int
AS
BEGIN
	DECLARE @Error int
	INSERT INTO Sales.StoreContact
	(CustomerID, ContactID, ContactTypeID)
	VALUES
	(@CustomerID, @ContactID, @ContactTypeID)
	SET @Error = @@ERROR
	IF @Error = 0
		PRINT 'New Record Inserted'
	ELSE
		BEGIN
			IF @Error = 547
			PRINT 'Foreign Key violation.'
			ELSE 
			PRINT 'Unknown error.'
		END
END
