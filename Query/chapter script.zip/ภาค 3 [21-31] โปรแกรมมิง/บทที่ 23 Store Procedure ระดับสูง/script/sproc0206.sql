DECLARE @m nvarchar(1)
DECLARE @g nvarchar(1)
EXEC spGetMaritalAndGender 2 , @m OUTPUT, @g OUTPUT
SELECT @m AS Marital_Status, @g AS Gender