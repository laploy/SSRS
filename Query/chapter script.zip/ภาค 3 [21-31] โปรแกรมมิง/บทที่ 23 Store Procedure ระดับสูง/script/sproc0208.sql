DECLARE @p1 money, @p2 money 
EXECUTE Production.spGetList '%Bikes%', 8, 
@p1 OUT, 
@p2 OUTPUT
SELECT @p1 AS 'Max Price', @p2 AS 'Min Price'