DECLARE @myTitle nvarchar(50)
EXEC spGetTitle 1 , @myTitle OUTPUT
SELECT @myTitle AS Title