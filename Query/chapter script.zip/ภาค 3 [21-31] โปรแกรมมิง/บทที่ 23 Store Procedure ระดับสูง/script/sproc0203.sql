USE AdventureWorks
GO
CREATE PROCEDURE spGetTitle
@employeeID INT,
@title nvarchar(50) OUTPUT
AS
BEGIN
SELECT @title = Title 
FROM HumanResources.Employee 
WHERE EmployeeID = @employeeID
END