ALTER PROC spEmployee
@Title nvarchar(50) = NULL
AS
IF @Title IS NULL
SELECT * FROM HumanResources.Employee
ELSE
SELECT * FROM HumanResources.Employee
WHERE Title LIKE @Title + '%'