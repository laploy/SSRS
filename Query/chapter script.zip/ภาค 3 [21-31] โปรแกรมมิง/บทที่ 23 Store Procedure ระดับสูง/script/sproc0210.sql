USE AdventureWorks
GO

IF OBJECT_ID('dbo.spGetSortedEmployee') IS NOT NULL
	DROP PROC dbo.spGetSortedEmployee;
GO

CREATE PROC dbo.spGetSortedEmployee
	@colname AS sysname = NULL
AS
DECLARE @msg AS NVARCHAR(500);
IF @colname IS NULL
BEGIN
	SET @msg = 'A value must be supplied for parameter @colname.';
	RAISERROR(@msg, 16, 1);
	RETURN 0;
END

IF @colname NOT IN('EmployeeID', 'Title', 'VacationHours')
BEGIN
	SET @msg =
	'Valid values for @colname are: '
	+ '''EmployeeID'', ''Title'', ''VacationHours''.';
	RAISERROR(@msg, 16, 1);
	RETURN 0;
END

IF @colname = 'EmployeeID'
	SELECT EmployeeID, Title, VacationHours
	FROM HumanResources.Employee
	ORDER BY EmployeeID;
RETURN 1;

ELSE IF @colname = 'Title'
	SELECT EmployeeID, Title, VacationHours
	FROM HumanResources.Employee
	ORDER BY Title;
RETURN 1;

ELSE IF @colname = 'VacationHours'
	SELECT EmployeeID, Title, VacationHours
	FROM HumanResources.Employee
	ORDER BY VacationHours;
RETURN 1;

GO