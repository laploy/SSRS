ALTER PROCEDURE spGetMaritalAndGender
	@employeeID INT
	,@marital nvarchar(1) OUTPUT
	,@gender nvarchar(1) OUT
AS
   SELECT @marital = MaritalStatus, @gender = Gender
   FROM HumanResources.Employee 
   WHERE EmployeeID = @employeeID