USE AdventureWorks;
GO
IF OBJECT_ID ( 'Production.spGetList', 'P' ) IS NOT NULL 
	DROP PROCEDURE Production.spGetList;
GO
CREATE PROCEDURE Production.spGetList @Product varchar(40) 
	, @MaxPrice money 
	, @TopPrice money OUTPUT
	, @MinPrice money OUT
AS
	SELECT p.[Name] AS Product, p.ListPrice AS 'List Price'
	FROM Production.Product AS p
	WHERE p.ListPrice > 0 AND p.ListPrice < @MaxPrice;
SET @TopPrice = (SELECT MAX(p.ListPrice)
	FROM Production.Product AS p
	WHERE p.ListPrice > 0 AND  p.ListPrice < @MaxPrice);
SET @MinPrice = (SELECT MIN(p.ListPrice)
	FROM Production.Product AS p
	WHERE p.ListPrice > 0 AND  p.ListPrice < @MaxPrice);
GO