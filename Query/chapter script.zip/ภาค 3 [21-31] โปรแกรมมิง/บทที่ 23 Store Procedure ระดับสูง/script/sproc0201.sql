USE AdventureWorks
GO
CREATE PROC spEmployee
AS
	SELECT * FROM HumanResources.Employee