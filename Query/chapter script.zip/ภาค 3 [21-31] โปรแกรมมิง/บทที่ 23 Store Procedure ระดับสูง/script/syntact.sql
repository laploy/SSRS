CREATE PROCEDURE|PROC <sproc name>
	[<parameter name> [schema.]<data type> [VARYING] [= <default value>] [OUT
[PUT]][,
	<parameter name> [schema.]<data type> [VARYING] [= <default value>]
[OUT[PUT]][,
	. . .
	. . .
	     ]]
[WITH
	RECOMPILE| ENCRYPTION | [EXECUTE AS { CALLER|SELF|OWNER|<�user name�>}]
[FOR REPLICATION]
AS
	<code> | EXTERNAL NAME <assembly name>.<assembly class>
