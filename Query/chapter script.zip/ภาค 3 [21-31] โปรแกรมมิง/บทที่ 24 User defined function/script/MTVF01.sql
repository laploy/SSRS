USE AdventureWorks;
GO
SELECT     
	p.ProductID, 
	p.Name, 
	v.VendorID,
	v.MinOrderQty, 
	v.MaxOrderQty
FROM Production.Product p INNER JOIN 
	Purchasing.ProductVendor v ON 
		p.ProductID = v.ProductID
WHERE p.ProductID = 1;
GO