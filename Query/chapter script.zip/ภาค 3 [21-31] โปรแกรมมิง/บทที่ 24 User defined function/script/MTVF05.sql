USE AdventureWorks;
GO
SELECT 
	ContactID, FirstName, 
	LastName, JobTitle, ContactType
FROM dbo.ufnGetContactInformation(2200);
GO
SELECT 
	ContactID, FirstName, 
	LastName, JobTitle, ContactType
FROM dbo.ufnGetContactInformation(5);
GO