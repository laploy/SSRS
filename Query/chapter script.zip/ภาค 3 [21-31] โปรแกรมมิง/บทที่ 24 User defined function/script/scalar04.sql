USE Laploy;
GO
SELECT dbo.Factorial(NULL) AS factorial;
SELECT dbo.Factorial(-1) AS factorial;
SELECT dbo.Factorial(0) AS factorial;
SELECT dbo.Factorial(5) AS factorial;
SELECT dbo.Factorial(32) AS factorial;
GO