USE Laploy;
GO
CREATE FUNCTION dbo.Factorial (@n int = 1)
RETURNS decimal(38, 0)
WITH RETURNS NULL ON NULL INPUT
AS
BEGIN
	RETURN
	(CASE
		WHEN @n <= 0 THEN NULL
		WHEN @n > 1 THEN 
			CAST(@n AS float) * dbo.Factorial (@n - 1)
		WHEN @n = 1 THEN 1
	END);
END;
GO