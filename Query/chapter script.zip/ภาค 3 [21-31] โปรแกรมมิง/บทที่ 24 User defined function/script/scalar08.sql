USE Laploy;
GO
SELECT *
FROM sys.objects
WHERE type = 'FN';
GO