USE AdventureWorks;
GO
SELECT * FROM Numbers
GO