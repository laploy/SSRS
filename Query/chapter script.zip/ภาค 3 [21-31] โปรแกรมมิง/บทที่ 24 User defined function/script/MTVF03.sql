USE AdventureWorks;
GO
SELECT TOP 10
	pp.ProductID,
	m.Name,
	m.VendorID,
	m.MinOrderQty, 
	m.MaxOrderQty
FROM Production.Product AS pp
CROSS APPLY GetMinMax(pp.ProductID) AS m
GO