DECLARE @x AS int = 123;
DECLARE @y AS int = -123;
PRINT 'x = ' + CAST(@x AS char(10));
PRINT 'y = ' + CAST(@y AS char(10));
PRINT 'ABS x = ' + CAST(ABS(@x) AS char(10));
PRINT 'ABS y = ' + CAST(ABS(@y) AS char(10));
GO