USE Laploy;
GO
SELECT dbo.CircleArea(10) AS area;
SELECT dbo.CircleArea(2.5)AS area;
SELECT dbo.CircleArea(NULL)AS area;
SElECT PI() as PI;
GO