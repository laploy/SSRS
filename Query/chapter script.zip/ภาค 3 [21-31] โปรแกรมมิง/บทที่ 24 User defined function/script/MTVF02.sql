USE AdventureWorks;
GO
CREATE FUNCTION GetMinMax(@ProdId int) 
RETURNS @Trans TABLE
(
	ProductID int,
	Name nvarchar(60),
	VendorID int,
	MinOrderQty int,
	MaxOrderQty int
)
AS
BEGIN
	INSERT INTO @Trans
	SELECT     
		p.ProductID, 
		p.Name, 
		v.VendorID,
		v.MinOrderQty, 
		v.MaxOrderQty
	FROM Production.Product p INNER JOIN 
		Purchasing.ProductVendor v ON 
			p.ProductID = v.ProductID
	WHERE p.ProductID = @ProdID;
	RETURN
END
GO