USE Laploy;
GO
SELECT dbo.FactorialCTE(NULL) AS factorial;
SELECT dbo.FactorialCTE(-1) AS factorial;
SELECT dbo.FactorialCTE(0) AS factorial;
SELECT dbo.FactorialCTE(5) AS factorial;
SELECT dbo.FactorialCTE(32) AS factorial;
SELECT dbo.FactorialCTE(33) AS factorial;
GO