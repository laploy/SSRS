USE GolfClub;
GO
SELECT 
	m.MemberID, m.LastName, 
	m.MemberType,
	t.Fee, t.Type
FROM Member m CROSS JOIN Type t;
GO