USE GolfClub;
GO
SELECT 
	m.MemberID, m.LastName, 
	m.MemberType,
	t.Fee, t.Type
FROM Member m INNER JOIN Type t
	ON m.MemberType = t.Type;
GO