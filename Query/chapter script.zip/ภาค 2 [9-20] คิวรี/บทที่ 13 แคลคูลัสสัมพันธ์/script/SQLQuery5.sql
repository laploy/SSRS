USE GolfClub;
GO
SELECT m.LastName, m.FirstName
FROM Member m, Entry e, Tournament t
WHERE m.MemberID = e.MemberID
	AND e.TourID = t.TourID
	AND t.TourType = 'Open' AND e.Year = 2006
GO