USE AdventureWorks2008;
GO
DECLARE @a CHAR(30);
DECLARE @b CHAR(10);
DECLARE myCursor CURSOR for

	WITH JobList(Job, JobCount) AS 
	(
		SELECT TOP 10 JobTitle, COUNT(*)
		FROM HumanResources.Employee
		GROUP BY JobTitle
	)
	SELECT Job, JobCount 
	FROM JobList;

OPEN myCursor;
FETCH FROM myCursor INTO @a, @b;
WHILE @@FETCH_STATUS = 0
BEGIN
	IF @a LIKE 'Acc%' PRINT @a + '  ' + @b;
	FETCH FROM myCursor INTO @a, @b;
END;

CLOSE myCursor;
DEALLOCATE myCursor;
GO