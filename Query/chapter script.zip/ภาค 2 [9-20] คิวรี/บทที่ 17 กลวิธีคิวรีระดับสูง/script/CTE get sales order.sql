USE AdventureWorks2008;
GO
WITH myCTE (SalesPersonID, NumberOfOrders)
AS
(
    SELECT SalesPersonID, COUNT(*)
    FROM Sales.SalesOrderHeader
    GROUP BY SalesPersonID
)
SELECT TOP 10 
	p.BusinessEntityID AS ID, 
	p.FirstName, p.LastName,
	cte.NumberOfOrders
FROM Person.Person AS p
    JOIN myCTE AS cte
    ON p.BusinessEntityID = CTE.SalesPersonID
GO