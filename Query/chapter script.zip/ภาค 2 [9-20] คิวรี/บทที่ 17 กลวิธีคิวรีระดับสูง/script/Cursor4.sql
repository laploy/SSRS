USE AdventureWorks2008;
GO
DECLARE @a CHAR(10);
DECLARE @b CHAR(10);
DECLARE myCursor CURSOR for
	SELECT TOP 100 BusinessEntityID, FirstName
	FROM Person.Person;
		OPEN myCursor
		FETCH NEXT FROM myCursor INTO @a,@b;
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @b LIKE 'Ja%' EXEC uspGetEmployeeManagers @a;
			FETCH NEXT FROM myCursor INTO @a,@b;
		END;
CLOSE myCursor;
DEALLOCATE myCursor;
GO