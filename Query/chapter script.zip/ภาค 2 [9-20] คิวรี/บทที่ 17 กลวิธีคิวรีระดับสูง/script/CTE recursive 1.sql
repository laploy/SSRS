USE Northwind;
GO
WITH cte (CategoryID, myCounter, myList, ProductID, myLenght) AS 
(
	SELECT 
		CategoryID, 
		COUNT(*) OVER (PARTITION BY CategoryID),
		CAST(ProductID AS VARCHAR(100)),
		ProductID, 1
	FROM Products
	UNION ALL
	SELECT 
		cte.CategoryID, 
		cte.myCounter,
		CAST(cte.myList + ', ' 
			+ CAST(p.ProductID AS CHAR(2)) AS VARCHAR(100)),
		p.ProductID, cte.myLenght+1
	FROM Products p, cte
	WHERE p.CategoryID = cte.CategoryID 
		AND p.ProductID > cte.ProductID
)
SELECT 
	CategoryID, myCounter AS Quntity, 
	myList AS [All products in this category]
FROM cte
WHERE myLenght = myCounter
ORDER BY CategoryID;
GO