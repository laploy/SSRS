USE AdventureWorks2008;
GO
DECLARE @a CHAR(10);
DECLARE @b CHAR(10);
DECLARE myCursor CURSOR SCROLL for
	SELECT TOP 100 BusinessEntityID, FirstName
	FROM Person.Person;
		OPEN myCursor
		FETCH NEXT FROM myCursor INTO @a,@b;
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @a > 95 PRINT @a + @b;
			FETCH NEXT FROM myCursor INTO @a,@b;
		END;
		PRINT '==================='
		FETCH PRIOR FROM myCursor INTO @a,@b;
		WHILE @a > 95
		BEGIN
			PRINT @a + @b;
			FETCH PRIOR  FROM myCursor INTO @a,@b;
		END;
CLOSE myCursor;
DEALLOCATE myCursor;
GO