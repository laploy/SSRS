USE AdventureWorks;
GO
WITH DirectReports
(
	Name, Title, ID, 
	Level1, Hierarchical
)AS 
(
	SELECT 
		CONVERT(varchar(255), 
			c.FirstName + ' ' + c.LastName),
        e.Title,
        e.EmployeeID,
        1,
        CONVERT(varchar(255), 
			c.FirstName + ' ' + c.LastName)
    FROM HumanResources.Employee AS e
    JOIN Person.Contact AS c 
		ON e.ContactID = c.ContactID 
    WHERE e.ManagerID IS NULL
    UNION ALL
    SELECT 
		CONVERT(varchar(255), 
			REPLICATE (' + ' , Level1) +
			c.FirstName + ' ' + c.LastName),
        e.Title,
        e.EmployeeID,
        Level1 + 1,
        CONVERT (varchar(255), 
			RTRIM(Hierarchical) + ' + ' + 
			FirstName + ' ' + LastName)
    FROM HumanResources.Employee as e
    JOIN Person.Contact AS c 
		ON e.ContactID = c.ContactID
    JOIN DirectReports AS d 
		ON e.ManagerID = d.ID
)
SELECT *
FROM DirectReports 
ORDER BY Hierarchical;
GO