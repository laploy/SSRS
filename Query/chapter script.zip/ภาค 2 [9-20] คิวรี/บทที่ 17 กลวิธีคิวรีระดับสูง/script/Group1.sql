USE AdventureWorks2008;
GO
WITH JobList(Job, JobCount) AS 
(
    SELECT TOP 10 JobTitle, COUNT(*)
    FROM HumanResources.Employee
    GROUP BY JobTitle
)
SELECT Job, JobCount 
FROM JobList
GO