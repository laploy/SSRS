USE Laploy;
GO
WITH c (S, X, Y) AS
(
	SELECT X, X, Y FROM XY am
	UNION ALL
	SELECT 
		CAST(c.S+rm.X AS VARCHAR(50))
		,rm.X ,rm.Y
	FROM XY rm, c
	WHERE rm.Y > c.Y
)
SELECT * FROM c;
GO