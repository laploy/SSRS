USE AdventureWorks2008;
GO
DECLARE @a CHAR(10);
DECLARE @b CHAR(10);
DECLARE myCursor CURSOR for
	SELECT TOP 10 BusinessEntityID, FirstName
	FROM Person.Person;
		OPEN myCursor
		FETCH NEXT FROM myCursor INTO @a,@b;
		WHILE @@FETCH_STATUS = 0
		BEGIN
			PRINT @a + @b;
			FETCH NEXT FROM myCursor INTO @a,@b;
		END;
CLOSE myCursor;
DEALLOCATE myCursor;
GO