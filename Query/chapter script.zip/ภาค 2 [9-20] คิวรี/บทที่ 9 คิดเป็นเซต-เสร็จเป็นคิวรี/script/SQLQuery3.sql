USE Northwind;
GO
SELECT OrderID, ProductID, Quantity
FROM  [Order Details]
GROUP BY OrderID, ProductID, Quantity
HAVING MIN(Quantity) = MAX(Quantity);
GO