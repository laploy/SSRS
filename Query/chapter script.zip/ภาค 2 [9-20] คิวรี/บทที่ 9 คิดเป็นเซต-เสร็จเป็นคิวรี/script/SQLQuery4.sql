USE AdventureWorks;
GO
SELECT 
	ProductID, 
	OrderQty, 
	OrderQty*10 AS Multi, 
	SUM(UnitPrice) AS Total
FROM Sales.SalesOrderDetail
	WHERE OrderQty > 20
	GROUP BY OrderQty, ProductID
	HAVING ProductID > 890
GO