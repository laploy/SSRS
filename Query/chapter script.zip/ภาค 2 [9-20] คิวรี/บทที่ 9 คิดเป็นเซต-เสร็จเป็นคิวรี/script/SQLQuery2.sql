USE Northwind;
GO
SELECT OrderID
FROM  [Order Details]
GROUP BY OrderID
HAVING MIN(Quantity) = MAX(Quantity);
GO