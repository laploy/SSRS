USE Northwind;
GO
SELECT DISTINCT OrderID
FROM [Order Details] AS D1
WHERE NOT EXISTS
(
	SELECT *
	FROM [Order Details] AS D2
	WHERE D1.OrderID = D2.OrderID
	AND D1.Quantity <> D2.Quantity
);
GO