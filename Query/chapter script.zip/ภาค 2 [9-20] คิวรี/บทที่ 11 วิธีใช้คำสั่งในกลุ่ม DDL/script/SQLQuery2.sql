USE AdventureWorks;
GO
SELECT
	referencing_schema_name, 
	referencing_entity_name, 
	referencing_class_desc
FROM sys.dm_sql_referencing_entities 
(
	'Production.Product', 'OBJECT'
);
GO