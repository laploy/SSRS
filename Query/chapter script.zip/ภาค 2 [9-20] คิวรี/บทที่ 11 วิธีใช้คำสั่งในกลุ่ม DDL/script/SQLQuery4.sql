USE [Northwind]
GO
IF  EXISTS 
(
	SELECT * FROM sys.objects 
	WHERE object_id = OBJECT_ID(N'[dbo].[Test01]') 
		AND type in (N'U')
)
	DROP TABLE [dbo].[Test01]
GO