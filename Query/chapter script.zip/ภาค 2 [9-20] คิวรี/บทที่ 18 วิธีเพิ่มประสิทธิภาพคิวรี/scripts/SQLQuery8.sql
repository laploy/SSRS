USE AdventureWorks;
GO
CREATE UNIQUE CLUSTERED INDEX 
	CIX_vTotalCustomerOrders_CustomerID 
		ON vTotalCustomerOrders(CustomerID)
GO