USE AdventureWorks;
GO
SELECT 
	oh.CustomerID, 
	SUM(LineTotal)
FROM Sales.SalesOrderDetail od 
	JOIN Sales.SalesOrderHeader oh
		ON od.SalesOrderID=oh.SalesOrderID
GROUP BY oh.CustomerID
GO