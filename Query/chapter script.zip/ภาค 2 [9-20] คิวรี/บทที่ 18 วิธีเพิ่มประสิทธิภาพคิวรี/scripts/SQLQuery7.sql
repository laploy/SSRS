USE AdventureWorks;
GO
CREATE VIEW vTotalCustomerOrders
WITH SCHEMABINDING
AS
	SELECT 
		oh.CustomerID, 
		SUM(LineTotal) AS OrdersTotalAmt, 
		COUNT_BIG(*) AS TotalOrderLines
	FROM Sales.SalesOrderDetail od 
		JOIN Sales.SalesOrderHeader oh
			ON od.SalesOrderID=oh.SalesOrderID
	GROUP BY oh.CustomerID;
GO