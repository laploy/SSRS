USE AdventureWorks;
GO
CREATE INDEX IDX_OrderDetail_OrderID_TotalLine
	ON Sales.SalesOrderDetail (SalesOrderID) 
		INCLUDE (LineTotal);
GO