USE AdventureWorks;
GO
SELECT 
	c.CustomerID, 
	SUM(LineTotal)
FROM Sales.SalesOrderDetail od 
	JOIN Sales.SalesOrderHeader oh
		ON od.SalesOrderID=oh.SalesOrderID
	JOIN Sales.Customer c 
		ON oh.CustomerID=c.CustomerID
GROUP BY c.CustomerID
GO