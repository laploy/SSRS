SELECT *
FROM [dbo].[DatabaseLog]; 
GO