USE AdventureWorks;
GO
EXEC Person.GetTenContacts 6100;
GO