USE Northwind;
GO
SELECT 
	e.firstName,
	c.CompanyName
FROM Employees e
 JOIN Orders o ON 
	e.employeeID=o.employeeID
 JOIN Customers c ON 
	c.customerID=o.customerID
 ORDER BY 
	e.firstName,
	c.CompanyName;
GO