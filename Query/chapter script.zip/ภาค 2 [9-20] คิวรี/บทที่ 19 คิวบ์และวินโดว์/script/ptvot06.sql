USE Northwind;
GO
SELECT
	c.CompanyName,
	[1] as [Nancy],[2] as [Andrew],[3] as [Janet],
	[4] as [Margi],[5] as [Steve],[6] as [Mick],
	[7] as [Rob],[8] as [Laura],[9] as [Anne]
FROM 
(
	SELECT customerID,employeeID  FROM Orders
) o
PIVOT 
(
	COUNT(employeeID) 
	FOR employeeID IN 
	(
		[1],[2],[3],[4],[5],[6],[7],[8],[9]
	)
) p
JOIN Customers c ON p.customerID=c.customerID
ORDER BY c.CompanyName
GO