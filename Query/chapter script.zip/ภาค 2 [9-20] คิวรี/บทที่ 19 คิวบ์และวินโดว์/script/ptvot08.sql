USE AdventureWorks;
GO
SELECT 
	pt.Discount,
	ISNULL(pt.[711],0.00) As Product711,
	ISNULL(pt.[747],0.00) As Product747,
	ISNULL(pt.[776],0.00) As Product776
FROM
(
	SELECT 
		sod.LineTotal, 
		sod.ProductID, 
		sod.UnitPriceDiscount as Discount
	FROM Sales.SalesOrderDetail sod
) so
PIVOT
(
	SUM(so.LineTotal)
	FOR so.ProductID IN ([776], [711], [747])
) AS pt
ORDER BY pt.Discount;
GO