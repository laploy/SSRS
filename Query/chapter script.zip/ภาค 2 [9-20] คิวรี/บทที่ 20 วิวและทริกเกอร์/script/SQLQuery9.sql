USE AdventureWorks;
GO
IF OBJECT_ID ('dbo.Trigger201','TR') IS NOT NULL
    DROP TRIGGER dbo.Trigger201;
GO
CREATE TRIGGER Trigger201
ON Production.Product
AFTER DELETE 
AS
   EXEC msdb.dbo.sp_send_dbmail
        @profile_name = 'AdventureWorks Administrator',
        @recipients = 'myname@mailserver.com',
        @body = 'Data in tabel Prouct has been deleted',
        @subject = 'Warning';
GO