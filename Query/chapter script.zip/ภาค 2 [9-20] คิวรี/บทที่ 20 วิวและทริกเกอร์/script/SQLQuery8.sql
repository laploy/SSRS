USE AdventureWorks;
GO
UPDATE Sales.Customer
SET TerritoryID = 2
WHERE CustomerID = 1;
GO