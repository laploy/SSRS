USE AdventureWorks;
GO
SELECT CustomerID, TerritoryID
FROM Sales.Customer
WHERE CustomerID = 1
GO