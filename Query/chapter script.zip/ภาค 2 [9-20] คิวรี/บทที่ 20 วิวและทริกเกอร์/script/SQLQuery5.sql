USE AdventureWorks2008;
GO
SELECT *
FROM dbo.person01_view
WHERE Rate < 7
GO