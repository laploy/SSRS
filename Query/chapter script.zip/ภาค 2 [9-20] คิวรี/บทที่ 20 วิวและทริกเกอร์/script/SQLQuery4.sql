USE AdventureWorks2008;
GO
SELECT TOP 10 *
FROM dbo.person01_view
GO