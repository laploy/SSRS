USE AdventureWorks2008;
GO
IF OBJECT_ID ('person01_view', 'V') IS NOT NULL
	DROP VIEW person01_view ;
GO
CREATE VIEW person01_view
AS 
	SELECT
		e.BusinessEntityID AS PersonID, 
		p.FirstName, 
		p.LastName,
		e.JobTitle, 
		h.Rate
	FROM HumanResources.Employee AS e 
		INNER JOIN HumanResources.EmployeePayHistory AS h 
			ON e.BusinessEntityID = h.BusinessEntityID
		INNER JOIN Person.Person AS p 
			ON e.BusinessEntityID = p.BusinessEntityID;
GO

