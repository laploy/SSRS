USE GolfClub;
GO
SELECT DISTINCT  
	Lastname, 
	FirstName 
FROM Entry INNER JOIN Member 
	ON Entry.MemberID = Member.MemberID

GO