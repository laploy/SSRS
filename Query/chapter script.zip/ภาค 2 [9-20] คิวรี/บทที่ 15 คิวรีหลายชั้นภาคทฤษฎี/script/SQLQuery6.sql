USE GolfClub;
GO
SELECT e.MemberID
FROM Entry e
WHERE e.TourID IN
(
	SELECT t.TourID
	FROM Tournament t
	WHERE t.TourType = 'Open'
)
GO