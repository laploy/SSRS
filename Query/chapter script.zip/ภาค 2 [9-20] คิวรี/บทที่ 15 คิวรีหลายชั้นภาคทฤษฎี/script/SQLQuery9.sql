USE GolfClub;
GO
SELECT m.LastName, m.FirstName
FROM Member m
WHERE EXISTS
(
	SELECT * FROM Entry e 
	WHERE e.MemberID = m.MemberID
)
GO