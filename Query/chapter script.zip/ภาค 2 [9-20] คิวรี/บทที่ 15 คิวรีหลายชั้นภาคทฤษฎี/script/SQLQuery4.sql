USE GolfClub;
GO
SELECT t.TourID
FROM Tournament t
WHERE t.TourType = 'Open'
GO