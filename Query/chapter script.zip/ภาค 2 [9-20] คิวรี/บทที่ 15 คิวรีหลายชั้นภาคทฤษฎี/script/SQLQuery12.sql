USE GolfClub;
GO
SELECT m.Lastname, m.FirstName
FROM Member m
WHERE NOT EXISTS
(
	SELECT * 
	FROM Entry e 
		INNER JOIN Tournament t 
			ON e.TourID = t.TourID
	WHERE 
		e.MemberID = m.MemberID AND 
		t.TourType = 'Open'
)
GO