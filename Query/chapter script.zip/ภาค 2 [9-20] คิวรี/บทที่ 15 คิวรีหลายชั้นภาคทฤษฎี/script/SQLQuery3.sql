USE GolfClub;
GO
SELECT *
FROM Entry e
WHERE e.TourID NOT IN (36, 38, 40)
GO