USE GolfClub;
GO
SELECT e.MemberID
FROM Entry e INNER JOIN Tournament t 
	ON e.TourID = t.TourID
WHERE t.TourType = 'Open'
GO