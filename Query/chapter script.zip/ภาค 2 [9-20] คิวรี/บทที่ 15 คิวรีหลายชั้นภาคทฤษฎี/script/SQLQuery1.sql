USE GolfClub;
GO
SELECT *
FROM Entry e
WHERE 
	e.TourID= 36 OR 
	e.TourID= 38 OR 
	e.TourID= 40
GO