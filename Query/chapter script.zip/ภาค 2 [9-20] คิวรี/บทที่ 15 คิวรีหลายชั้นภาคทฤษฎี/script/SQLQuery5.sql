USE GolfClub;
GO
SELECT e.MemberID
FROM Entry e
GO