USE GolfClub;
GO
SELECT m.Lastname, m.FirstName
FROM Member m
WHERE NOT EXISTS
(
	SELECT * 
	FROM Entry e 
	WHERE e.MemberID = m.MemberID
)
GO