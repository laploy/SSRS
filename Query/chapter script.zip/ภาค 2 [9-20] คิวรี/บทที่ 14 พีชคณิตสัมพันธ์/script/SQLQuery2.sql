USE Laploy;
GO
SELECT 
	P#, 
	PName AS PN, 
	Color, 
	Weight AS WT,
	City
FROM P;
GO