USE Laploy;
GO
SELECT * FROM S WHERE City = 'London';
GO
SELECT * FROM S WHERE S# = 'S1' OR S# = 'S2';
GO
SELECT * FROM S WHERE City = 'London'
UNION ALL
SELECT * FROM S WHERE S# = 'S1' OR S# = 'S2';
GO