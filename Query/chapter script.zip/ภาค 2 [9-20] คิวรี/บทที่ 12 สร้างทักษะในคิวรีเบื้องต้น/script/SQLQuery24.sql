DECLARE @myString	AS NCHAR(200) = 'Hello, world';
DECLARE @myLenght	AS INT = LEN(@myString);
DECLARE @walker		AS INT = 1
WHILE @walker <= @myLenght
	BEGIN
		PRINT 'Char No.' +
		CAST(@walker AS char(2)) + 
		' = ' +  
		SUBSTRING(@myString, @walker, 1);
		SET @walker += 1;
	END
GO