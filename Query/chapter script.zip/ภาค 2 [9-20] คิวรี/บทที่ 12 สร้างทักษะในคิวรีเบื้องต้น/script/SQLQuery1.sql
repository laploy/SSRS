USE AdventureWorksLT2008;
SELECT TOP 5 *
FROM SalesLT.Product;
GO
SELECT TOP 5 Name, Color, Size
FROM SalesLT.Product;
GO
SELECT TOP 5 Name, Color, Size
FROM SalesLT.Product
WHERE Size IS NOT NULL;
GO