USE AdventureWorksLT2008;
SELECT COALESCE(Size, 'TOTAL') Name, SUM(ListPrice) ListPrice
FROM SalesLT.Product
WHERE Size = 'M' OR Size = 'L' OR Size = 'XL' OR Size = 'L'
GROUP BY Size WITH ROLLUP
--SELECT * FROM SalesLT.Product