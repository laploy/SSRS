USE AdventureWorksLT2008;
GO
SELECT 
	COALESCE(Size, 'Grand Total') [Product Size], 
	COUNT(Size) Quntity,
	SUM(ListPrice) SubTotal
FROM SalesLT.Product
WHERE 
	Size = 'M' OR 
	Size = 'L' OR 
	Size = 'XL' OR 
	Size = 'S'
GROUP BY Size WITH ROLLUP;
GO