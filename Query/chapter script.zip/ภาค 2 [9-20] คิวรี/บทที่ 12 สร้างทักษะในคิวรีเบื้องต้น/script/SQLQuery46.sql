USE AdventureWorks2008;
GO
SELECT 
	COALESCE(Color, '') Color,
	COUNT(Color) Quantity
FROM Production.Product
WHERE Color IS NOT NULL
GROUP BY Color
GO