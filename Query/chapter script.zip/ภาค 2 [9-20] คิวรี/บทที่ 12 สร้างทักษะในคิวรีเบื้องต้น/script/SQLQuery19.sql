USE AdventureWorks2008;
SELECT TOP 5 FirstName, BusinessEntityID
FROM Person.Person;
GO
SELECT TOP 5 Name, DepartmentID
FROM HumanResources.Department;
GO

SELECT TOP 5 FirstName, BusinessEntityID
FROM Person.Person
UNION ALL
SELECT '====================', NULL
UNION ALL
SELECT TOP 5 Name, DepartmentID
FROM HumanResources.Department;
GO