USE AdventureWorks2008;
SELECT TOP 10 
	FirstName,
	LastName,
	(
		Title + ' ' +
		SUBSTRING(FirstName,1,1) + '.' +
		SUBSTRING(LastName,1,1)  + '. ' +
		FirstName + ' ' +
		LastName
	)FullName
FROM Person.Person
WHERE Title IS NOT NULL;
GO