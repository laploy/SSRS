USE AdventureWorksLT2008;
SELECT TOP 5 ProductID, Name, 'No data' AS Size
FROM SalesLT.Product
WHERE Size IS NULL
GO

SELECT TOP 10 ProductID, Name, 
	CASE
		WHEN Size IS NULL THEN 'No Data'
		WHEN Size = 'L' THEN 'Large'
		WHEN Size = 'S'  THEN 'Small'		
		WHEN Size = 'M'  THEN 'Median'		
		ELSE Size
	END
FROM SalesLT.Product
GO