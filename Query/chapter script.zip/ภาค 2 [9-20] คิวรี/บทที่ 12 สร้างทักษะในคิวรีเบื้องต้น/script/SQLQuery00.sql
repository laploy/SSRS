-- get table name
SELECT *
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'

-- Listing a Table's Columns
select column_name, data_type, ordinal_position
from information_schema.columns
where table_schema = 'SalesLT'
and table_name   = 'Address'

-- Listing indexed columns for a table
select a.name table_name,
b.name index_name,
d.name column_name,
c.index_column_id
from sys.tables a,
sys.indexes b,
sys.index_columns c,
sys.columns d
where a.object_id = b.object_id
and b.object_id = c.object_id
and b.index_id  = c.index_id
and c.object_id = d.object_id
and c.column_id = d.column_id
and a.name      = 'Address'


