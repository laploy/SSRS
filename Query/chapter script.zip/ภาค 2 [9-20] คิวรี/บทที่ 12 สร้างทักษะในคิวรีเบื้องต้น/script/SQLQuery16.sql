USE AdventureWorksLT2008;
SELECT column_name, data_type, ordinal_position
FROM INFORMATION_SCHEMA.COLUMNS
WHERE table_schema = 'SalesLT'
AND table_name   = 'Address'
GO