WITH x (Title, cnt, list, EmployeeID, len1) AS 
(
		SELECT Title, COUNT(*) OVER (PARTITION BY Title),
			CAST(FirstName AS VARCHAR(100)),
			EmployeeID, 1
		FROM Employees
	UNION ALL
		SELECT x.Title, x.cnt,
			CAST(x.list + ', ' + e.FirstName AS VARCHAR(100)),
			e.EmployeeID, x.len1+1
		FROM Employees e, x
		WHERE e.Title = x.Title AND e.EmployeeID > x. EmployeeID
)
SELECT Title,list
FROM x
WHERE len1 = cnt
order by 1;
GO
