USE Northwind;
GO
SELECT 
	x.*, 
	y.*, 
	DATEDIFF(Day, NancyHD, AndrewHD) AS [Day diffence]
FROM
(
	SELECT FirstName, HireDate AS AndrewHD
	FROM Employees
	WHERE FirstName = 'Andrew'
) x,
(
	SELECT FirstName, HireDate AS NancyHD
	FROM Employees
	WHERE FirstName = 'Nancy'
) y;
GO