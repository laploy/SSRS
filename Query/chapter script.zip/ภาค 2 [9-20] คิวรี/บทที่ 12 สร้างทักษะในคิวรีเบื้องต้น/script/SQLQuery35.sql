USE Northwind;
SELECT A.ProductID, A.ProductName, A.UnitsInStock,
	(SELECT sum(B.UnitsInStock) FROM Products B
		WHERE B.ProductID <= A.ProductID) AS RunningTotal
FROM Products A
ORDER BY 4
GO