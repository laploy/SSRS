USE AdventureWorksLT2008;
SELECT TOP 10 ProductID, Name, ListPrice
FROM SalesLT.Product
ORDER BY NEWID();
GO