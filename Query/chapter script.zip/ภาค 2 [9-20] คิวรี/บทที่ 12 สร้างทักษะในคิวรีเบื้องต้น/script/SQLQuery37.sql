USE Northwind;
SELECT SUM(UnitPrice)AS TotalProductPrice
	FROM Products 
	WHERE ProductID < 11
GO
SELECT 
	ProductID AS Code, 
	UnitPrice AS [Product Price],
	(UnitPrice/myTotal)*100 AS [---- % ----] 
FROM
(
	SELECT 
		ProductID, 
		UnitPrice,
		SUM(UnitPrice) OVER() AS myTotal
	FROM Products
	WHERE ProductID < 11
) x
GO