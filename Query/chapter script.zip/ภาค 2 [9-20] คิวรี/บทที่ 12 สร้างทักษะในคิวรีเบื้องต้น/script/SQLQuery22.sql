USE Northwind;
SELECT *
FROM Categories c INNER JOIN
	Products p ON c.CategoryID = p.CategoryID;
GO