WITH x (JobTitle, MyCounter, MyList, EmployeeID, MyLength) AS 
(
	SELECT Title, 
		COUNT(*) OVER(PARTITION BY Title),
		CAST(FirstName AS VARCHAR(100)),
		EmployeeID, 1
	FROM Employees
	UNION ALL ----------------------
	SELECT x.JobTitle, x.MyCounter,
		CAST(x.MyList + ', ' + e.FirstName AS VARCHAR(100)),
		e.EmployeeID, x.MyLength + 1
	FROM Employees e, x
	WHERE e.Title = x.JobTitle AND e.EmployeeID > x.EmployeeID
)
SELECT JobTitle, myList
FROM x
WHERE MyLength = MyCounter
ORDER BY 1;
GO