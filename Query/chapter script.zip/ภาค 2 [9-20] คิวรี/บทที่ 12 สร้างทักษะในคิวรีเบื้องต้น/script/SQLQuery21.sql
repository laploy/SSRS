USE Northwind;
SELECT p.ProductName, c.CategoryName
FROM Categories c, Products p
WHERE c.CategoryID = p.CategoryID;
GO