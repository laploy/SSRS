USE Northwind;
SELECT Title AS TitleA, 
	COUNT(*) OVER(PARTITION BY Title) AS LengthA,
	CAST(A.FirstName AS VARCHAR(100)) AS NameA,
	EmployeeID AS EmployeeIDA,
	1 AS CounterA
FROM Employees A
GO