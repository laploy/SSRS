USE Northwind;
SELECT *, DATEDIFF(DAY, a.HireDate, a.NextHireDate) diffDate
FROM
(
	SELECT 
		b.EmployeeID, 
		b.FirstName, 
		b.HireDate,
		(
			SELECT MIN(c.HireDate)
			FROM Employees c
			WHERE c.HireDate > b.HireDate
		)	AS NextHireDate
	FROM Employees b
) a
ORDER BY HireDate;
GO