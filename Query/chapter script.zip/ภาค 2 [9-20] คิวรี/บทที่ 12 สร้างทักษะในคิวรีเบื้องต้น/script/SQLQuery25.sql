USE AdventureWorksLT2008;
SELECT TOP 10 
	ProductID, 
	Name, 
	LEN(Name) AS 'Lenght of Name'
FROM SalesLT.Product
ORDER BY 'Lenght of Name';
GO