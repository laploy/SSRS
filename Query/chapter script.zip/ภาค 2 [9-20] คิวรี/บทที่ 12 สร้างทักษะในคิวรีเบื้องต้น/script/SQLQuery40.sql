USE Northwind;
SELECT *,
	YEAR(y.BirthDate) - YEAR(x.BirthDate) AS DifferYear,
	MONTH(x.BirthDate) - MONTH(y.BirthDate) AS DifferMonth
FROM
	(SELECT FirstName, BirthDate
	FROM Employees
	WHERE FirstName = 'Nancy') x,
	
	(SELECT FirstName, BirthDate
	FROM Employees
	WHERE FirstName = 'Anne') y;
GO