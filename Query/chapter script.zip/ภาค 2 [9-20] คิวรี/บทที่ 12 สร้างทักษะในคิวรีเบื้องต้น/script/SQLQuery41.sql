USE Northwind;
SELECT *,
	DATEDIFF(DAY, x.BirthDate, y.BirthDate) * 24 AS DiffHour,
	DATEDIFF(DAY, x.BirthDate, y.BirthDate) * 24 * 60 AS DiffMin,
	DATEDIFF(DAY, x.BirthDate, y.BirthDate) * 24 * 60 * 60 AS Diffsec
FROM
	(SELECT FirstName, BirthDate
	FROM Employees
	WHERE FirstName = 'Nancy') x,
	
	(SELECT FirstName, BirthDate
	FROM Employees
	WHERE FirstName = 'Anne') y;
GO