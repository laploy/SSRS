USE AdventureWorksLT2008;
GO
SELECT TOP 10 ProductID, Name,
	CASE WHEN Color = 'Black' OR Color = 'Multi'
		THEN 'X' ELSE ''
	END AS Black,
	CASE WHEN Color = 'Red' OR Color = 'Multi'
		THEN 'X' ELSE ''
	END AS Red,
	CASE WHEN Color = 'White' OR Color = 'Multi'
		THEN 'X' ELSE ''
	END AS White
FROM SalesLT.Product
WHERE Color = 'Black' OR
	Color = 'Red' OR
	Color = 'White' OR
	Color = 'Multi';
GO