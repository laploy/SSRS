USE AdventureWorksLT2008;
SELECT TOP 10 
	ProductID, 
	Name, 
	REPLACE(Name, 'Classic', 'Vintage') AS FullName
FROM SalesLT.Product
GO