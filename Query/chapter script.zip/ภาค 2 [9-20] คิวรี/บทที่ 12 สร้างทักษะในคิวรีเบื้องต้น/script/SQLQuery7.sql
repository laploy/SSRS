USE AdventureWorksLT2008;
SELECT TOP 10 Name, ListPrice,
	CASE 
		WHEN ListPrice >= 1000 THEN 'Too expensive'
		WHEN ListPrice <= 33 THEN 'Too low'
		ELSE 'OK'
	END AS Status
FROM SalesLT.Product
GO