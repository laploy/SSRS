USE Northwind;
WITH X (JobTitle, MyLength, MyList, EmployeeID, MyCounter) AS 
(
	SELECT Title AS TitleA, 
		COUNT(*) OVER(PARTITION BY Title) AS LengthA,
		CAST(A.FirstName AS VARCHAR(100)) AS NameA,
		EmployeeID AS EmployeeIDA,
		1 AS CounterA
	FROM Employees A
	UNION ALL ----------------------
	SELECT X.JobTitle, X.MyLength,
		CAST(X.MyList + ', ' + B.FirstName AS VARCHAR(100)),
		B.EmployeeID, X.MyCounter + 1
	FROM Employees B, X
	WHERE B.Title = X.JobTitle AND B.EmployeeID > X.EmployeeID
)
SELECT X.JobTitle, X.myList
FROM X
WHERE X.MyCounter = X.MyLength
ORDER BY 1;
GO