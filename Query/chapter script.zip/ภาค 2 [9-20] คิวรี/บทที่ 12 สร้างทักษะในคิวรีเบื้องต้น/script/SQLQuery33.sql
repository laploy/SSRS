USE AdventureWorks2008;
GO
SELECT SalesOrderID, ProductID, OrderQty,
	(SELECT SUM(OrderQty) 
		FROM Sales.SalesOrderDetail )AS Total,
	(SELECT AVG(OrderQty)
		FROM Sales.SalesOrderDetail )AS Average,
	(SELECT MIN(OrderQty)
		FROM Sales.SalesOrderDetail )AS Minimum,
	(SELECT MAX(OrderQty)
		FROM Sales.SalesOrderDetail )AS Maximum
FROM Sales.SalesOrderDetail 
GO