USE Northwind;
SELECT TOP 10 o.OrderID, o.ShipName, t.Total
FROM Orders o, 
(
	SELECT OrderID AS id, SUM(UnitPrice) AS Total
	FROM [Order Details]
	GROUP BY OrderID
) t
WHERE o.OrderID = t.id
GO