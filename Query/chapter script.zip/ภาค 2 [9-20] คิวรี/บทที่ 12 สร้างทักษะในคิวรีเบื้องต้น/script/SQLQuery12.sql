USE AdventureWorksLT2008;
SELECT TOP 5 ProductID, Name, Color, ListPrice
FROM SalesLT.Product
ORDER BY 1
GO

SELECT TOP 5 ProductID, Name, Color, ListPrice
FROM SalesLT.Product
ORDER BY 2
GO

SELECT TOP 5 ProductID, Name, Color, ListPrice
FROM SalesLT.Product
ORDER BY 4
GO
