USE Northwind;
GO
SELECT c.CustomerID, CompanyName
FROM Customers c
LEFT OUTER JOIN Orders o
	ON c.CustomerID = o.CustomerID
WHERE o.CustomerID IS NULL;
GO