USE Northwind;
GO
SELECT 
	o1.CustomerID, 
	o1.OrderID, 
	o1.OrderDate
FROM Orders o1
WHERE o1.OrderDate =	
	(
		SELECT Min(o2.OrderDate)
		FROM Orders o2
		WHERE o2.CustomerID = o1.CustomerID
	)
ORDER BY CustomerID;
GO