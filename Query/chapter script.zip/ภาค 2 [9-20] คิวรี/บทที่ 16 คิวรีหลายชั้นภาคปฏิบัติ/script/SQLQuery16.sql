USE Northwind;
GO
SELECT 
	cu.CompanyName,
	(
		SELECT Min(OrderDate)
		FROM Orders o
		WHERE o.CustomerID = cu.CustomerID
	)
AS 'Order Date'
FROM Customers cu
GO