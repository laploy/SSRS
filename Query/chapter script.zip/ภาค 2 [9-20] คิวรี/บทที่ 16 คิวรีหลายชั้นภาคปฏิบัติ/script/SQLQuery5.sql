USE pubs;
GO
SELECT s.Stor_ID, s.Stor_Name
FROM Discounts d
RIGHT OUTER JOIN Stores s
	ON d.Stor_ID = s.Stor_ID
	WHERE d.Stor_ID IS NULL
GO