USE Northwind;
GO
SELECT DISTINCT o.OrderDate, od.ProductID
FROM Orders o
JOIN [Order Details] od
	ON o.OrderID = od.OrderID
	WHERE o.OrderDate = 
	(
		SELECT MIN(OrderDate) 
		FROM Orders
	)
GO