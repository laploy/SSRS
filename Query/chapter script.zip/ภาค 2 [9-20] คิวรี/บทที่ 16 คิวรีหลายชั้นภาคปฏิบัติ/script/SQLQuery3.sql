USE pubs;
GO
SELECT s.stor_id, stor_name
FROM Stores s
JOIN Discounts d
	ON s.stor_id = d.stor_id;
GO