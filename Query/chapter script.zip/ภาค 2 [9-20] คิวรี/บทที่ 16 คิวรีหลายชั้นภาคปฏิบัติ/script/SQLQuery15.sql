USE Northwind;
GO
SELECT Min(OrderDate)
FROM Orders
GO