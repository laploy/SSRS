USE pubs;
GO
SELECT stor_id, stor_name
FROM Stores
WHERE stor_id IN 
(
	SELECT stor_id 
	FROM Discounts
)
GO