USE Northwind;
GO
SELECT CustomerID, MIN((OrderDate)) AS OrderDate
INTO #MinOrderDates
FROM Orders
GROUP BY CustomerID
ORDER BY CustomerID
GO