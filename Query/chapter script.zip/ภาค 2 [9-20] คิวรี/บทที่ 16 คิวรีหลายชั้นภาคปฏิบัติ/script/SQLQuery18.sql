USE Northwind;
GO
SELECT 
	cu.CompanyName,
	ISNULL
	(
		(
			SELECT 
				CAST(MIN(o.OrderDate) 
					AS CHAR(20))
			FROM Orders o
			WHERE o.CustomerID = cu.CustomerID
		),
		'- - No order - -'
	) AS 'Order Date'
FROM Customers cu
GO