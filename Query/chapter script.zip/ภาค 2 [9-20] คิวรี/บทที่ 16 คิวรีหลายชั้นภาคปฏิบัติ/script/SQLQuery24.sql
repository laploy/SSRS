USE Northwind;
GO
SELECT DISTINCT c.CompanyName
FROM Customers AS c
JOIN
	(SELECT CustomerID
	FROM Orders o
	JOIN [Order Details] od
		ON o.OrderID = od.OrderID
		JOIN Products p
			ON od.ProductID = p.ProductID
			WHERE p.ProductName = 'tofu') AS spen
			ON c.CustomerID = spen.CustomerID
JOIN
	(SELECT CustomerID
	FROM Orders o
	JOIN [Order Details] od
		ON o.OrderID = od.OrderID
		JOIN Products p
			ON od.ProductID = p.ProductID
			WHERE ProductName = 'Vegie-spread') AS spap
			ON c.CustomerID = spap.CustomerID;
GO