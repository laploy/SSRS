USE Northwind;
GO
SELECT CustomerID, OrderID, OrderDate
FROM Orders
ORDER BY CustomerID
GO