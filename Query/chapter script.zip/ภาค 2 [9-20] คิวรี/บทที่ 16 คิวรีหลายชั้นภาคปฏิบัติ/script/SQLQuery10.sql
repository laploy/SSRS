USE Northwind;
GO
SELECT o.CustomerID, o.OrderID, o.OrderDate
FROM Orders o
JOIN #MinOrderDates t
	ON o.CustomerID = t.CustomerID
	AND o.OrderDate = t.OrderDate
	ORDER BY o.CustomerID
DROP TABLE #MinOrderDates
GO