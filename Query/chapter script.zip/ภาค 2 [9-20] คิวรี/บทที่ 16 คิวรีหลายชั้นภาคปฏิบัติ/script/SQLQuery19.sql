USE Northwind;
GO
SELECT cu.CompanyName,
	ISNULL
	(
		(
			SELECT MIN(o.OrderDate)
			FROM Orders o
			WHERE o.CustomerID = cu.CustomerID), 
			'No order'
		)AS 'Order Date'
FROM Customers cu
GO