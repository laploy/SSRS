USE Northwind;
GO
SELECT CustomerID, CompanyName
FROM Customers cu
WHERE NOT EXISTS
	(
		SELECT OrderID
		FROM Orders o
		WHERE o.CustomerID = cu.CustomerID
	);
GO