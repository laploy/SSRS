USE Northwind;
GO
SELECT c.CompanyName
FROM Customers AS c
	JOIN Orders AS o
		ON c.CustomerID = o.CustomerID
	JOIN [Order Details] AS od
		ON o.OrderID = od.OrderID
	JOIN Products AS p
		ON od.ProductID = p.ProductID
WHERE p.ProductName = 'tofu'
GO