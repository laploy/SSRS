USE Northwind;
GO
SELECT DISTINCT cu.CustomerID, cu.CompanyName
FROM Customers cu
JOIN Orders o
	ON cu.CustomerID = o.CustomerID;
GO