USE Northwind;
GO
SELECT CompanyName
FROM Customers;
GO