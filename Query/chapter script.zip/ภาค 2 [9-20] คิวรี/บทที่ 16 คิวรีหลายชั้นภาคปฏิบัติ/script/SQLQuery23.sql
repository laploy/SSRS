USE Northwind;
GO
SELECT CustomerID
	FROM Orders o
	JOIN [Order Details] od
		ON o.OrderID = od.OrderID
		JOIN Products p
			ON od.ProductID = p.ProductID
			WHERE ProductName = 'Vegie-spread';
GO