USE pubs;
GO
SELECT stor_id 
FROM Discounts 
WHERE stor_id IS NOT NULL
GO