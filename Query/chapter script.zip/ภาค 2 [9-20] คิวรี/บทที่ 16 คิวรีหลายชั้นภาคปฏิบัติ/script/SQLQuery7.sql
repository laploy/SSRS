USE pubs;
GO
SELECT stor_id, stor_name
FROM Stores
WHERE stor_id NOT IN
	(
		SELECT stor_id 
		FROM Discounts 
		WHERE stor_id IS NOT NULL
	);
GO