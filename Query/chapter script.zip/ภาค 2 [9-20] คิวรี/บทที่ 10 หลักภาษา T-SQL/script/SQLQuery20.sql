USE AdventureWorks2008;
SELECT TOP 
(
	SELECT COUNT(*)/1000 
	FROM Purchasing.PurchaseOrderDetail
)
	PurchaseOrderID, 
	DueDate, 
	OrderQty
FROM Purchasing.PurchaseOrderDetail;
GO