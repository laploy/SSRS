DECLARE @Foo AS int = 123;
DECLARE @Bar AS int = 456;
PRINT @Foo;
PRINT @Bar;
GO
---------------------------
DECLARE @Foo AS int = 456;
PRINT @Foo;
PRINT @Bar;
GO