USE AdventureWorks2008;
SELECT TOP 15 ProductID, Name, 
	COALESCE(Color, 'Not specified') AS Color
From Production.Product
GO