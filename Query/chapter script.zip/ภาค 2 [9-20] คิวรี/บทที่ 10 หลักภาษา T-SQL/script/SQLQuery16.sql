DECLARE @myNumber INT = 2;
DECLARE @cost MONEY = 5;
DECLARE @myName VARCHAR(20) = 'Laploy';
DECLARE @birthDate DATE = '01/01/2008';
DECLARE @firstShift TIME = '12:30:05';
SELECT @myNumber, @cost, @myName, @birthDate, @firstShift;
GO

DECLARE 
	@myNumber INT = 2,
	@cost MONEY = 5,
	@myName VARCHAR(20) = 'Laploy',
	@birthDate DATE = '01/01/2008',
	@firstShift TIME = '12:30:05';
SELECT @myNumber, @cost, @myName, @birthDate, @firstShift;
GO
