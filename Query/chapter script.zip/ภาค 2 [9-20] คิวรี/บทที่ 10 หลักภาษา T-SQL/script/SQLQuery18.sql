USE AdventureWorks2008;
SELECT DISTINCT OrderQty
FROM Purchasing.PurchaseOrderDetail
	WHERE OrderQty BETWEEN 1 AND 350
	ORDER BY OrderQty;
GO

USE AdventureWorks2008;
	SELECT DISTINCT OrderQty
	FROM Purchasing.PurchaseOrderDetail
		WHERE OrderQty BETWEEN 1 AND 350
INTERSECT
	SELECT OrderQty
	FROM Purchasing.PurchaseOrderDetail
		WHERE OrderQty BETWEEN 175 AND 250
ORDER BY OrderQty;
GO