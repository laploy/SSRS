USE AdventureWorks2008;
SELECT TOP 10
	FirstName,
	MiddleName,
	LastName
FROM Person.Person
TABLESAMPLE (10 PERCENT);
GO