USE AdventureWorks2008;
DECLARE @TableVar TABLE 
	(
		Name nchar(30),
		Color char(10),
		ListPrice money
	);

INSERT INTO @TableVar (Name, Color, ListPrice)
SELECT Name, Color, ListPrice
FROM Production.Product
WHERE Name LIKE 'LL Mountain Frame%'

SELECT * FROM @TableVar

SELECT * FROM @TableVar
WHERE Color = 'Black';

GO