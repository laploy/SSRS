USE AdventureWorks2008;
	SELECT DISTINCT OrderQty
	FROM Purchasing.PurchaseOrderDetail
		WHERE OrderQty BETWEEN 100 AND 350
EXCEPT
	SELECT OrderQty
	FROM Purchasing.PurchaseOrderDetail
		WHERE OrderQty BETWEEN 250 AND 300
ORDER BY OrderQty;
GO