USE AdventureWorks2008;
SELECT TOP 15 ProductID, Name, Color
From Production.Product
GO