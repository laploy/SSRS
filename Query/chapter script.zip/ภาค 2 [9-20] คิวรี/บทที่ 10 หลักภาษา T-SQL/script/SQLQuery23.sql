DECLARE @d1 date = '1995-04-19';
DECLARE @d2 date = '2009-02-26';
SELECT
@d1 AS Date1,
@d2 AS Date2,
DATEDIFF(YEAR, @d1, @d2) AS YearsDifference;
GO