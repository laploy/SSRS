USE AdventureWorks2008;
CREATE TABLE #Shift
(
	Name VARCHAR(50) NOT NULL,
	StartTime TIME NOT NULL,
	EndTime TIME NOT NULL,
);
INSERT INTO #Shift
	(Name,StartTime,EndTime)
VALUES
	('Noon Part-time','12:00:00','16:00:00'),
	('Evening Part-time','16:00:00','20:00:00'),
	('Midnight Part-time','00:00:00','04:00:00');
SELECT * FROM #Shift;
DROP TABLE #Shift;
GO