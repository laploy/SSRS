USE AdventureWorks2008;
SELECT TOP 15 ProductID, Name, 
(
	CASE WHEN Color = 'Black' THEN 
		NULL
	ELSE 
		Color
	END
) AS Color
From Production.Product
GO