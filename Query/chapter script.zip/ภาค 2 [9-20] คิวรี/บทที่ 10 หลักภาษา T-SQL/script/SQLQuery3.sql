USE AdventureWorks2008;
DECLARE @x AS money;
DECLARE @y AS char(30);

SET @y = 'Hello';
SELECT @x = ListPrice FROM Production.Product
WHERE Name = 'Bike Wash - Dissolver';

PRINT @x;
PRINT @y;