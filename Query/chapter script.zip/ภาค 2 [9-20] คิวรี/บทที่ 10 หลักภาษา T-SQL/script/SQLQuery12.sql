USE AdventureWorks2008;
SELECT TOP 15 ProductID, Name, 
(CASE
	WHEN Color IS NOT NULL THEN Color
	WHEN Color IS NULL THEN 'Not specified' 
END)AS Color
From Production.Product
GO