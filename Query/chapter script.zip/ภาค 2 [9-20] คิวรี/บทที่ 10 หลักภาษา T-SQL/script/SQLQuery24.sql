DECLARE @start_time time(1) = '06:25:19.1'; 
DECLARE @end_time time = '18:25:19.1234567'; 
SELECT
	@start_time AS start_time,
	@end_time AS end_time,
	DATEDIFF(HOUR, @start_time, @end_time) AS EndStartDiff;
GO