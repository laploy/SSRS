USE AdventureWorks2008;
SELECT TOP 15 ProductID, Name, 
	NULLIF(Color, 'Black') AS Color
From Production.Product
GO